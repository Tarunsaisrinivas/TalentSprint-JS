
public class MergeSorted {

    public static void main(String[] args) {
        int[] a = {1, 4, 7};
        int[] b = {2, 3, 5, 6};

        int i = 0, j = 0, k = 0;
        int[] merged = new int[a.length + b.length];

        while (i < a.length && j < b.length) {
            if (a[i] < b[j]) {
                merged[k++] = a[i++];
            } else {
                merged[k++] = b[j++];
            }
        }

        while (i < a.length) {
            merged[k++] = a[i++];
        }
        while (j < b.length) {
            merged[k++] = b[j++];
        }

        System.out.print("Merged Array: [");
        for (int x = 0; x < merged.length; x++) {
            System.out.print(merged[x]);
            if (x < merged.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}
